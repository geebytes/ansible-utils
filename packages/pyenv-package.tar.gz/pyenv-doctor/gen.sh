#!/bin/sh -e
autoreconf
